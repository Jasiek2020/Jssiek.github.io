# Banners of the Vale: app package

This folder is the game as an installable app ("Progressive Web App").
Put these files on any free web host, open the address on your phone, and
install it. It then opens full-screen from your home screen and works offline.

## Files
- `index.html`: the whole game
- `manifest.webmanifest`: app name, colours, icons, full-screen request
- `sw.js`: service worker that saves the game for offline play
- `icon-*.png`, `apple-touch-icon.png`: home-screen icons

## Put it online with GitHub Pages (free, permanent)
1. Create a free account at github.com.
2. Make a new **public** repository, for example `banners-of-the-vale`.
3. Choose **Add file → Upload files**, drag in all the files from this
   folder (not the folder itself), and commit.
4. Go to **Settings → Pages**. Under *Build and deployment*, choose
   **Deploy from a branch**, pick `main` and `/ (root)`, and save.
5. After a minute or two your game is at
   `https://YOUR-NAME.github.io/banners-of-the-vale/`.

## Install it on your phone
- **Android (Chrome):** open the address, then tap the ⋮ menu and choose
  **Install app** (or **Add to Home screen**).
- **iPhone (Safari):** open the address, tap **Share**, then
  **Add to Home Screen**.

Open it once while online so it can save itself. After that it runs offline.

## Updating the game later
Replace `index.html` with the new version, then change `VERSION` at the top
of `sw.js` (for example `bov-v1` to `bov-v2`) and upload both. Phones pick
up the update the next time the app is opened online.
